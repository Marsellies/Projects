import { useCallback, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Categories, SortPopup, PizzaBlock } from '../components';
import LoadingBlock from '../components/PizzaBlock/LoadingBlock';
import {
  fetchPizzas,
  setCategory,
  setSortBy,
  addPizzaToCard,
} from '../store/reducers/pizzasFilter';

const categoryNames = [
  'Мясные',
  'Вегетарианская',
  'Гриль',
  'Острые',
  'Закрытые',
];
const sortItems = [
  { name: 'популярнсти', type: 'popular', order: 'desc' },
  { name: 'цене', type: 'price', order: 'desc' },
  { name: 'алфавиту', type: 'name', order: 'asc' },
];

function Home() {
  const dispatch = useDispatch();
  const items = useSelector(({ items }) => items);
  const cartItems = useSelector(({ itemsCart }) => itemsCart);
  const isLoaded = useSelector(({ isLoaded }) => isLoaded);
  const { category, sortBy } = useSelector((pizzasFilter) => pizzasFilter);
  useEffect(() => {
    dispatch(fetchPizzas(sortBy, category));
  }, [category, sortBy]);

  const onSelectCategory = useCallback((index) => {
    dispatch(setCategory(index));
  }, []);

  const onSelectSortType = useCallback((type) => {
    dispatch(setSortBy(type));
  }, []);

  const handleAddPizzaToCard = (obj) => {
    dispatch(addPizzaToCard(obj));
  };

  return (
    <div className="container">
      <div className="content__top">
        <Categories
          activeCategory={category}
          onClickCategory={onSelectCategory}
          items={categoryNames}
        />
        <SortPopup
          activeSortType={sortBy.type}
          items={sortItems}
          onClickSortType={onSelectSortType}
        />
      </div>
      <h2 className="content__title">Все пиццы</h2>
      <div className="content__items">
        {isLoaded
          ? items.map((item) => (
              <PizzaBlock
                onClickAddPizza={handleAddPizzaToCard}
                {...item}
                addedCount={
                  cartItems[item.id] && cartItems[item.id].itemsCart.length
                }
                key={item.id}
              />
            ))
          : Array(12)
              .fill(null)
              .map((_, index) => <LoadingBlock key={index} />)}
      </div>
    </div>
  );
}

export default Home;

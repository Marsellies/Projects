import { createSlice } from '@reduxjs/toolkit';

const pizzasFilter = createSlice({
  name: 'pizzasFilter',
  initialState: {
    pizzas: [],
    category: null,
    sortBy: {
      type: 'popular',
      order: 'desc',
    },
    items: [],
    isLoaded: false,
    itemsCart: {},
    totalPrice: 0,
    totalCount: 0,
  },
  reducers: {
    setSortBy(state, action) {
      state.sortBy = action.payload;
    },
    setCategory(state, action) {
      state.category = action.payload;
    },
    setPizzas(state, action) {
      state.items = action.payload;
      state.isLoaded = true;
    },
    setLoaded(state, action) {
      state.isLoaded = action.payload;
    },
    setTotalPrice(state, action) {
      state.totalPrice = action.payload;
    },
    setTotalCount(state, action) {
      state.totalCount = action.payload;
    },
    clearCart(state, action) {
      state.totalPrice = 0;
      state.totalCount = 0;
      state.itemsCart = {};
    },
    plusCartItem(state, action) {
      const newObjItems = [
        ...state.itemsCart[action.payload].itemsCart,
        state.itemsCart[action.payload].itemsCart[0],
      ];
      const newItems = {
        ...state.itemsCart,
        [action.payload]: {
          itemsCart: newObjItems,
          totalPrice: newObjItems.reduce((sum, obj) => obj.price + sum, 0),
        },
      };
      const totalCount = Object.keys(newItems).reduce(
        (sum, key) => newItems[key].itemsCart.length + sum,
        0
      );
      const totalPrice = Object.keys(newItems).reduce(
        (sum, key) => newItems[key].totalPrice + sum,
        0
      );
      state.itemsCart = newItems;
      state.totalCount = totalCount;
      state.totalPrice = totalPrice;
    },
    minusCartItem(state, action) {
      const oldItems = state.itemsCart[action.payload].itemsCart;
      const newObjItems =
        oldItems.length > 1
          ? state.itemsCart[action.payload].itemsCart.slice(1)
          : oldItems;
      const newItems = {
        ...state.itemsCart,
        [action.payload]: {
          itemsCart: newObjItems,
          totalPrice: newObjItems.reduce((sum, obj) => obj.price + sum, 0),
        },
      };
      const totalCount = Object.keys(newItems).reduce(
        (sum, key) => newItems[key].itemsCart.length + sum,
        0
      );
      const totalPrice = Object.keys(newItems).reduce(
        (sum, key) => newItems[key].totalPrice + sum,
        0
      );
      state.itemsCart = newItems;
      state.totalCount = totalCount;
      state.totalPrice = totalPrice;
    },
    removeCartItem(state, action) {
      const newItems = {
        ...state.itemsCart,
      };
      const currentTotalPrice = newItems[action.payload].totalPrice;
      const currentTotalCount = newItems[action.payload].itemsCart.length;
      delete newItems[action.payload];
      state.itemsCart = newItems;
      state.totalPrice = state.totalPrice - currentTotalPrice;
      state.totalCount = state.totalCount - currentTotalCount;
    },
    addPizzaToCard(state, action) {
      const currentPizzaItems = !state.itemsCart[action.payload.id]
        ? [action.payload]
        : [...state.itemsCart[action.payload.id].itemsCart, action.payload];
      const newItems = {
        ...state.itemsCart,
        [action.payload.id]: {
          itemsCart: currentPizzaItems,
          totalPrice: currentPizzaItems.reduce(
            (sum, obj) => obj.price + sum,
            0
          ),
        },
      };

      const totalCount = Object.keys(newItems).reduce(
        (sum, key) => newItems[key].itemsCart.length + sum,
        0
      );
      const totalPrice = Object.keys(newItems).reduce(
        (sum, key) => newItems[key].totalPrice + sum,
        0
      );

      state.itemsCart = newItems;
      state.totalCount = totalCount;
      state.totalPrice = totalPrice;
    },
  },
});

export const fetchPizzas = (sortBy, category) => (dispatch) => {
  dispatch(setLoaded(false));
  fetch(
    `http://localhost:3001/pizzas?${
      category !== null ? `category=${category}` : ''
    }&_sort=${sortBy.type}&_order=${sortBy.order}`
  )
    .then((res) => res.json())
    .then((json) => dispatch(setPizzas(json)));
};

export const {
  setSortBy,
  setCategory,
  setPizzas,
  setLoaded,
  setTotalPrice,
  setTotalCount,
  addPizzaToCard,
  clearCart,
  removeCartItem,
  plusCartItem,
  minusCartItem,
} = pizzasFilter.actions;
export default pizzasFilter.reducer;

import { applyMiddleware, compose, configureStore } from '@reduxjs/toolkit';
import categoryFilter from './reducers/pizzasFilter';
import thunk from 'redux-thunk';

const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

const store = configureStore(
  { reducer: categoryFilter },
  composeEnhancers(applyMiddleware(thunk))
);

export default store;
